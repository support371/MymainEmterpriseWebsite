/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    './pages/**/*.{js,ts,jsx,tsx,mdx}',
    './components/**/*.{js,ts,jsx,tsx,mdx}',
    './app/**/*.{js,ts,jsx,tsx,mdx}',
  ],
  theme: {
    extend: {
      colors: {
        'gem-teal': '#00d4d4',
        'gem-blue': '#38bdf8',
        'gem-bg': '#080c14',
        'gem-card': '#111827',
        'gem-border': '#1e2d40',
      },
      fontFamily: {
        display: ['Syne', 'sans-serif'],
        mono: ['Space Mono', 'monospace'],
        data: ['JetBrains Mono', 'monospace'],
      },
    },
  },
  plugins: [],
}
