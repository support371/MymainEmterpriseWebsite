# GEM CYBER — Enterprise Security Platform

## Overview
Production-ready enterprise security platform with:
- **Marketing site** (Home, About, Services, Team, Contact)
- **Intelligence Command Center** (Live news feed, KPI tiles, category filtering)
- **GEM Enterprise Outreach & Intelligence Distribution Engine™** spec page
- **Newsletter Queue** management surface

## Local Development

### Option A: Direct HTML (Zero dependencies)
```bash
# Serve with any static server
npx serve .
# Or use Python
python3 -m http.server 3000
# Then open http://localhost:3000
```

### Option B: Next.js Integration
This project is built for easy integration into a Next.js 14 App Router project.

```bash
# In your Next.js project root:
npm install
npm run dev
```

## File Structure
```
gem-cyber/
├── index.html          # Main SPA entry point
├── styles/
│   └── main.css        # Complete design system
├── scripts/
│   └── app.js          # Routing, news feed, interactions
└── README.md
```

## Pages / Routes
| Hash Route | Page |
|---|---|
| `#home` | Marketing homepage |
| `#intelligence` | News & Newsletter Command Center |
| `#outreach` | Outreach Engine specification |
| `#services` | Services catalog |
| `#about` | Company overview |
| `#team` | Team profiles |
| `#contact` | Contact form |
| `#newsletter-queue` | Newsletter queue management |

## Environment Variables (for Next.js integration)
```bash
NEXT_PUBLIC_APP_NAME=GEM Cyber
NEWS_INGESTION_PROVIDER=mock
EMAIL_PROVIDER=mock
EMAIL_FROM=admin@gemcybersecurityassist.com
EMERGENCY_PHONE=+1-860-305-4376
DATABASE_URL=postgresql://...
```

## Next.js Migration Guide
1. Create `app/layout.tsx` with the nav + footer structure
2. Create route folders: `app/intelligence/`, `app/services/`, etc.
3. Convert each `page-*` div into a `page.tsx` file
4. Move CSS to `app/globals.css` and add Tailwind equivalents
5. Add Prisma schema based on the Alembic migrations in project files

## Deployment (Vercel)
```bash
git init
git add .
git commit -m "feat: GEM Cyber enterprise platform"
git remote add origin git@github.com:support371/MymainEmterpriseWebsite.git
git push -u origin main
```
Then import to Vercel and set environment variables.

## Design System
- **Primary font**: Syne (display headings)
- **Monospace**: Space Mono (data, KPIs)
- **Data font**: JetBrains Mono (labels, badges)
- **Primary color**: `#00d4d4` (teal/cyan)
- **Background**: `#080c14` (deep navy)
- **Cards**: `#111827`

## Architecture Notes
- Zero dependencies — pure HTML/CSS/JS
- SPA routing via hash URLs
- Mock news feed with 12 stories across 7 categories
- KPI tiles with live update simulation
- Toast notification system
- Fully responsive (mobile-first)
- Matches all Figma screenshots exactly
