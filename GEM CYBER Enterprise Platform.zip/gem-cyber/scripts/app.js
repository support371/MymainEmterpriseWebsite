// GEM CYBER Enterprise Platform — Application Logic
'use strict';

// ===== ROUTING =====
const pages = ['home', 'intelligence', 'outreach', 'services', 'about', 'team', 'contact', 'newsletter-queue'];
let currentPage = 'home';

function navigate(page) {
  // Hide all pages
  document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
  document.querySelectorAll('.nav-link').forEach(l => l.classList.remove('active'));
  document.querySelectorAll('[data-page]').forEach(l => l.classList.remove('active'));

  // Show target page
  const el = document.getElementById(`page-${page}`);
  if (el) el.classList.add('active');

  // Highlight nav
  document.querySelectorAll(`[data-page="${page}"]`).forEach(l => l.classList.add('active'));

  currentPage = page;
  window.scrollTo(0, 0);

  // Hide intel tabs bar when not on intelligence
  const tabsBar = document.querySelector('.intel-tabs-bar');
  if (tabsBar) tabsBar.style.display = (page === 'intelligence') ? 'flex' : 'none';

  // Close mobile nav
  document.getElementById('navMobile').classList.remove('open');

  // Update hash
  history.pushState(null, '', `#${page}`);
}

// Handle nav links with data-page
document.querySelectorAll('[data-page]').forEach(el => {
  el.addEventListener('click', (e) => {
    const page = el.getAttribute('data-page');
    if (page) {
      e.preventDefault();
      navigate(page);
    }
  });
});

// Handle hash routing
function handleHash() {
  const hash = window.location.hash.replace('#', '') || 'home';
  if (pages.includes(hash)) navigate(hash);
}
window.addEventListener('popstate', handleHash);
handleHash();

// ===== MOBILE NAV =====
document.getElementById('navHamburger').addEventListener('click', () => {
  document.getElementById('navMobile').classList.toggle('open');
});

// ===== INTELLIGENCE FEED DATA =====
const stories = [
  {
    id: 1, cat: 'cybersecurity', catLabel: 'Cybersecurity',
    source: 'CISA FIELD ADVISORY', sourceIcon: 'C', timeAgo: '1d ago',
    title: 'CISA Pushes Lifecycle Governance to Eliminate Unsupported Edge Device Risk',
    excerpt: 'Organizations are advised to inventory, decommission, and continuously discover EOS edge devices under BOD 26-02.',
    img: 'data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 200"><rect fill="%230d1f2e" width="400" height="200"/><text x="200" y="110" text-anchor="middle" font-size="60" fill="%2300d4d420">⊕</text></svg>'
  },
  {
    id: 2, cat: 'crypto', catLabel: 'Crypto',
    source: 'INVESTING.COM', sourceIcon: 'I', timeAgo: '1d ago',
    title: 'Bitcoin Stabilizes as Traders Await Federal Guidance',
    excerpt: 'Institutional flows remain steady while regulatory direction remains the primary short-term catalyst.',
    img: 'data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 200"><rect fill="%231a0d2e" width="400" height="200"/><text x="200" y="110" text-anchor="middle" font-size="60" fill="%23fbbf2420">₿</text></svg>'
  },
  {
    id: 3, cat: 'tech', catLabel: 'Tech',
    source: 'TECHNEWSWORLD', sourceIcon: 'T', timeAgo: '2d ago',
    title: 'Gartner Warns Enterprises to Restrict Agentic AI Browsers',
    excerpt: 'Security teams are being urged to block unmanaged autonomous browser agents until policy controls catch up.',
    img: 'data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 200"><rect fill="%230d202e" width="400" height="200"/><text x="200" y="110" text-anchor="middle" font-size="60" fill="%2338bdf820">⊞</text></svg>'
  },
  {
    id: 4, cat: 'cybersecurity', catLabel: 'Cybersecurity',
    source: 'THE HACKER NEWS', sourceIcon: 'H', timeAgo: '2d ago',
    title: 'UEFI Exploit Chain Impacts Millions of Endpoint Motherboards',
    excerpt: 'Security teams are urged to prioritize firmware patching and DMA hardening controls this quarter.',
    img: 'data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 200"><rect fill="%231a1010" width="400" height="200"/><text x="200" y="110" text-anchor="middle" font-size="60" fill="%23f8717120">⚠</text></svg>'
  },
  {
    id: 5, cat: 'finance', catLabel: 'Finance',
    source: 'FOX BUSINESS', sourceIcon: 'F', timeAgo: '2d ago',
    title: 'S&P 500 Climbs as Cybersecurity Spend Outlook Improves',
    excerpt: 'Analysts expect enterprise security budgets to remain resilient despite broader market volatility.',
    img: 'data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 200"><rect fill="%231a1a0d" width="400" height="200"/><text x="200" y="110" text-anchor="middle" font-size="60" fill="%23fbbf2420">↗</text></svg>'
  },
  {
    id: 6, cat: 'tech', catLabel: 'Tech',
    source: 'SILICON VALLEY JOURNAL', sourceIcon: 'S', timeAgo: '2d ago',
    title: 'AI Accelerator Competition Intensifies for Next-Gen Model Training',
    excerpt: 'Compiler-level innovations are unlocking broader hardware options and lowering deployment costs.',
    img: 'data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 200"><rect fill="%230d1a2e" width="400" height="200"/><text x="200" y="110" text-anchor="middle" font-size="60" fill="%2300d4d420">◈</text></svg>'
  },
  {
    id: 7, cat: 'business', catLabel: 'Business',
    source: 'WSJ', sourceIcon: 'W', timeAgo: '3d ago',
    title: 'Executive Continuity Planning Surges as Cyber Threats Target C-Suite',
    excerpt: 'Boards are mandating executive-level threat briefings and personal security protocols for senior leadership.',
    img: 'data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 200"><rect fill="%230d150d" width="400" height="200"/><text x="200" y="110" text-anchor="middle" font-size="60" fill="%234ade8020">♟</text></svg>'
  },
  {
    id: 8, cat: 'realestate', catLabel: 'Real Estate',
    source: 'BLOOMBERG', sourceIcon: 'B', timeAgo: '3d ago',
    title: 'Property Portfolio Breach Response Frameworks Go Mainstream',
    excerpt: 'Commercial real estate operators are adopting enterprise security playbooks to protect smart building infrastructure.',
    img: 'data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 200"><rect fill="%2315100d" width="400" height="200"/><text x="200" y="110" text-anchor="middle" font-size="60" fill="%234ade8020">⌂</text></svg>'
  },
  {
    id: 9, cat: 'top', catLabel: 'Top Stories',
    source: 'REUTERS', sourceIcon: 'R', timeAgo: '4d ago',
    title: 'Global Risk Outlook: Geopolitical Tensions Drive Enterprise Security Spend',
    excerpt: 'Annual threat intelligence report shows record enterprise security budget allocations across North America and Europe.',
    img: 'data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 200"><rect fill="%230d1820" width="400" height="200"/><text x="200" y="110" text-anchor="middle" font-size="60" fill="%2300d4d420">◉</text></svg>'
  },
  {
    id: 10, cat: 'tech', catLabel: 'Tech',
    source: 'GADGET WEEKLY', sourceIcon: 'G', timeAgo: '4h ago',
    title: 'Samsung Galaxy Z TrifFold Debuts: A New Era for Foldable Devices',
    excerpt: 'The dual-hinge system promises a tablet-sized experience that fits in your pocket.',
    img: 'data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 200"><rect fill="%230d1a28" width="400" height="200"/><text x="200" y="110" text-anchor="middle" font-size="60" fill="%2338bdf820">◻</text></svg>'
  },
  {
    id: 11, cat: 'finance', catLabel: 'Finance',
    source: 'FOX BUSINESS', sourceIcon: 'F', timeAgo: '1h ago',
    title: 'Market Rally: S&P 500 hits new record as inflation data cools',
    excerpt: 'Fed policymaker floats further rate cuts as economy stays on the golden path.',
    img: 'data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 200"><rect fill="%231a150d" width="400" height="200"/><text x="200" y="110" text-anchor="middle" font-size="60" fill="%23fbbf2420">$</text></svg>'
  },
  {
    id: 12, cat: 'realestate', catLabel: 'Real Estate',
    source: 'AP NEWS', sourceIcon: 'A', timeAgo: '10h ago',
    title: 'US Home Sales Tick Up: First monthly rise in 2025',
    excerpt: 'Despite elevated prices, buyers are returning as mortgage rates stabilize near 6%.',
    img: 'data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 200"><rect fill="%23101a10" width="400" height="200"/><text x="200" y="110" text-anchor="middle" font-size="60" fill="%234ade8020">⌂</text></svg>'
  }
];

let currentCat = 'top';
let visibleCount = 9;
let filteredStories = [];

function getFilteredStories() {
  const cat = currentCat;
  return cat === 'top' ? stories : stories.filter(s => s.cat === cat);
}

function renderFeed() {
  filteredStories = getFilteredStories();
  const sort = document.getElementById('sortSelect')?.value || 'newest';
  if (sort === 'oldest') filteredStories = [...filteredStories].reverse();

  const grid = document.getElementById('storyGrid');
  if (!grid) return;

  const visible = filteredStories.slice(0, visibleCount);
  grid.innerHTML = visible.map(story => `
    <article class="story-card">
      <div class="story-img-placeholder" style="position:relative">
        <img src="${story.img}" alt="" style="position:absolute;inset:0;width:100%;height:100%;object-fit:cover" onerror="this.style.display='none'" />
        <span class="story-cat-badge cat-${story.cat}">${story.catLabel}</span>
      </div>
      <div class="story-body">
        <div class="story-meta">
          <span class="story-source-icon">${story.sourceIcon}</span>
          <span>${story.source}</span>
          <span>·</span>
          <span>${story.timeAgo}</span>
        </div>
        <h3 class="story-title">${story.title}</h3>
        <p class="story-excerpt">${story.excerpt}</p>
        <div class="story-footer">
          <div class="story-actions">
            <button class="story-action-btn" title="Bookmark">⊞</button>
            <button class="story-action-btn" title="Share">⊕</button>
          </div>
          <a href="#" class="story-read-link" onclick="return false">Read Story →</a>
        </div>
      </div>
    </article>
  `).join('');

  const loadBtn = document.getElementById('loadMoreBtn');
  if (loadBtn) {
    loadBtn.style.display = filteredStories.length > visibleCount ? 'inline-flex' : 'none';
  }
}

function loadMore() {
  visibleCount += 6;
  renderFeed();
  showToast('✓ Loaded more stories');
}

// Category tab filtering
document.querySelectorAll('.tab-pill').forEach(tab => {
  tab.addEventListener('click', () => {
    document.querySelectorAll('.tab-pill').forEach(t => t.classList.remove('active'));
    tab.classList.add('active');
    currentCat = tab.getAttribute('data-cat');
    visibleCount = 9;
    renderFeed();
  });
});

// ===== SCHEDULE UPLOAD =====
let uploadScheduled = false;
function scheduleUpload() {
  const btn = document.getElementById('scheduleBtn');
  if (!btn) return;

  if (!uploadScheduled) {
    uploadScheduled = true;
    btn.textContent = '✓ Upload Scheduled';
    btn.classList.remove('btn-primary');
    btn.style.background = 'var(--green)';

    // Update KPI
    const count = document.getElementById('storiesCount');
    if (count) {
      let n = parseInt(count.textContent);
      const interval = setInterval(() => {
        n += 1;
        count.textContent = n;
        if (n >= 56) clearInterval(interval);
      }, 80);
    }

    // Update dispatch time info
    const now = new Date();
    const nextRun = new Date(now.getTime() + 24 * 60 * 60 * 1000);
    const nextRunEl = document.getElementById('nextRun');
    const lastRunEl = document.getElementById('lastRun');
    if (nextRunEl) nextRunEl.textContent = nextRun.toISOString();
    if (lastRunEl) lastRunEl.textContent = now.toISOString();

    showToast('✓ Daily upload scheduled for 06:30 UTC tomorrow');

    setTimeout(() => {
      uploadScheduled = false;
      if (btn) {
        btn.textContent = 'Schedule Daily Upload';
        btn.classList.add('btn-primary');
        btn.style.background = '';
      }
    }, 5000);
  }
}

// ===== CONTACT FORM =====
function submitContact(e) {
  e.preventDefault();
  showToast('✓ Message sent! Our team will respond within 2 hours.');
  e.target.reset();
}

// ===== TOAST =====
let toastTimeout;
function showToast(message) {
  const toast = document.getElementById('toast');
  if (!toast) return;
  toast.textContent = message;
  toast.classList.add('show');
  clearTimeout(toastTimeout);
  toastTimeout = setTimeout(() => toast.classList.remove('show'), 3500);
}

// ===== SCROLL NAV =====
const nav = document.getElementById('mainNav');
window.addEventListener('scroll', () => {
  if (window.scrollY > 20) {
    nav.style.background = 'rgba(8, 12, 20, 0.98)';
  } else {
    nav.style.background = 'rgba(8, 12, 20, 0.92)';
  }
}, { passive: true });

// ===== DISPATCH PANEL DATA =====
function initDispatchPanel() {
  const now = new Date();
  const lastRun = new Date(now.getTime() - 12 * 60 * 60 * 1000);
  const nextRun = new Date();
  nextRun.setUTCHours(6, 30, 0, 0);
  if (nextRun < now) nextRun.setDate(nextRun.getDate() + 1);

  const nextEl = document.getElementById('nextRun');
  const lastEl = document.getElementById('lastRun');
  if (nextEl) nextEl.textContent = nextRun.toISOString();
  if (lastEl) lastEl.textContent = lastRun.toISOString();
}

// ===== INIT =====
document.addEventListener('DOMContentLoaded', () => {
  renderFeed();
  initDispatchPanel();

  // Init intel tabs bar visibility
  const tabsBar = document.querySelector('.intel-tabs-bar');
  if (tabsBar) tabsBar.style.display = 'none';

  // Handle hash on load
  handleHash();
});

// Expose globals
window.navigate = navigate;
window.scheduleUpload = scheduleUpload;
window.submitContact = submitContact;
window.loadMore = loadMore;
window.renderFeed = renderFeed;
